using AdminService as service from '../../srv/admin-service';

// ════════════════════════════════════════════════════════════════════
//  INVOICE LIST REPORT
// ════════════════════════════════════════════════════════════════════

annotate service.Invoices with @(

    UI.LineItem: [
        {   $Type : 'UI.DataField',
            Value : invoiceNumber,
            Label : 'Invoice No.',
            ![@UI.Importance] : #High },
        {   $Type : 'UI.DataField',
            Value : vendor.name,
            Label : 'Vendor',
            ![@UI.Importance] : #High },
        {   $Type : 'UI.DataField',
            Value : invoiceDate,
            Label : 'Invoice Date',
            ![@UI.Importance] : #Medium },
        {   $Type : 'UI.DataField',
            Value : dueDate,
            Label : 'Due Date',
            ![@UI.Importance] : #Low },
        {   $Type : 'UI.DataField',
            Value : amount,
            Label : 'Amount',
            ![@UI.Importance] : #High },
        {   $Type : 'UI.DataField',
            Value : currency,
            Label : 'CCY',
            ![@UI.Importance] : #Low },
        {   $Type         : 'UI.DataField',
            Value         : status,
            Label         : 'Status',
            Criticality   : statusCriticality,
            ![@UI.Importance] : #High }
    ],

    UI.SelectionFields: [ vendor_ID, status, invoiceDate, dueDate ],

    UI.HeaderInfo: {
        TypeName      : 'Invoice',
        TypeNamePlural: 'Invoices',
        Title         : { $Type: 'UI.DataField', Value: invoiceNumber },
        Description   : { $Type: 'UI.DataField', Value: vendor.name }
    },

    // ── Object page header ────────────────────────────────────────
    UI.HeaderFacets: [
        {   $Type : 'UI.ReferenceFacet',
            Target: '@UI.DataPoint#StatusDP',
            Label : 'Status' },
        {   $Type : 'UI.ReferenceFacet',
            Target: '@UI.DataPoint#AmountDP',
            Label : 'Amount' },
        {   $Type : 'UI.ReferenceFacet',
            Target: '@UI.FieldGroup#SubmissionInfo',
            Label : 'Submitted' }
    ],

    UI.DataPoint#StatusDP: {
        Value       : status,
        Title       : 'Status',
        Criticality : statusCriticality
    },

    UI.DataPoint#AmountDP: {
        Value : amount,
        Title : 'Amount'
    },

    UI.FieldGroup#SubmissionInfo: {
        Data: [
            { $Type: 'UI.DataField', Value: submittedBy, Label: 'By'   },
            { $Type: 'UI.DataField', Value: submittedAt, Label: 'On'   }
        ]
    },

    // ── Object page facets (4 tabs) ───────────────────────────────
    UI.Facets: [
        {   $Type : 'UI.ReferenceFacet',
            ID    : 'GeneralInfo',
            Label : 'General Information',
            Target: '@UI.FieldGroup#GeneralInfo' },
        {   $Type : 'UI.ReferenceFacet',
            ID    : 'LineItemsFacet',
            Label : 'Line Items',
            Target: 'items/@UI.LineItem' },
        {   $Type : 'UI.ReferenceFacet',
            ID    : 'AttachmentsFacet',
            Label : 'Attachments',
            Target: 'attachments/@UI.LineItem' },
        {   $Type : 'UI.ReferenceFacet',
            ID    : 'HistoryFacet',
            Label : 'Approval History',
            Target: 'approvalHistory/@UI.LineItem' }
    ],

    // ── General Information field group ───────────────────────────
    UI.FieldGroup#GeneralInfo: {
        Label: 'Invoice Details',
        Data : [
            { $Type: 'UI.DataField', Value: invoiceNumber,    Label: 'Invoice Number'     },
            { $Type: 'UI.DataField', Value: vendor_ID,        Label: 'Vendor'             },
            { $Type: 'UI.DataField', Value: invoiceDate,      Label: 'Invoice Date'       },
            { $Type: 'UI.DataField', Value: dueDate,          Label: 'Due Date'           },
            { $Type: 'UI.DataField', Value: amount,           Label: 'Amount'             },
            { $Type: 'UI.DataField', Value: currency,         Label: 'Currency'           },
            { $Type: 'UI.DataField', Value: status,           Label: 'Status'             },
            { $Type: 'UI.DataField', Value: notes,            Label: 'Notes'              },
            { $Type: 'UI.DataField', Value: createdBy,        Label: 'Created By'         },
            { $Type: 'UI.DataField', Value: createdAt,        Label: 'Created At'         },
            { $Type: 'UI.DataField', Value: approvedBy,       Label: 'Approved By'        },
            { $Type: 'UI.DataField', Value: approvedAt,       Label: 'Approved At'        },
            { $Type: 'UI.DataField', Value: approvalComments, Label: 'Approval Comments'  },
            { $Type: 'UI.DataField', Value: rejectedBy,       Label: 'Rejected By'        },
            { $Type: 'UI.DataField', Value: rejectedAt,       Label: 'Rejected At'        },
            { $Type: 'UI.DataField', Value: rejectionReason,  Label: 'Rejection Reason'   }
        ]
    }
);

// ── Computed criticality (virtual element added in service extension below) ──
extend service.Invoices with {
    virtual statusCriticality : Integer @UI.Hidden;
}

// ════════════════════════════════════════════════════════════════════
//  INVOICE LINE ITEMS
// ════════════════════════════════════════════════════════════════════

annotate service.InvoiceItems with @(
    UI.LineItem: [
        { $Type: 'UI.DataField', Value: lineNumber,  Label: 'Line No.'    },
        { $Type: 'UI.DataField', Value: description, Label: 'Description' },
        { $Type: 'UI.DataField', Value: quantity,    Label: 'Quantity'    },
        { $Type: 'UI.DataField', Value: unitPrice,   Label: 'Unit Price'  },
        { $Type: 'UI.DataField', Value: totalAmount, Label: 'Total'       }
    ],
    UI.HeaderInfo: {
        TypeName      : 'Line Item',
        TypeNamePlural: 'Line Items',
        Title: { $Type: 'UI.DataField', Value: description }
    }
);

// ════════════════════════════════════════════════════════════════════
//  ATTACHMENTS
// ════════════════════════════════════════════════════════════════════

annotate service.Attachments with @(
    UI.LineItem: [
        { $Type: 'UI.DataField', Value: fileName,   Label: 'File Name'   },
        { $Type: 'UI.DataField', Value: fileSize,   Label: 'Size (bytes)'},
        { $Type: 'UI.DataField', Value: mimeType,   Label: 'Type'        },
        { $Type: 'UI.DataField', Value: uploadedBy, Label: 'Uploaded By' },
        { $Type: 'UI.DataField', Value: uploadedAt, Label: 'Uploaded At' }
    ]
);

// ════════════════════════════════════════════════════════════════════
//  APPROVAL HISTORY
// ════════════════════════════════════════════════════════════════════

annotate service.ApprovalHistory with @(
    UI.LineItem: [
        { $Type: 'UI.DataField', Value: timestamp, Label: 'Date & Time'      },
        { $Type: 'UI.DataField', Value: action,    Label: 'Action'           },
        { $Type: 'UI.DataField', Value: actor,     Label: 'Performed By'     },
        { $Type: 'UI.DataField', Value: comments,  Label: 'Comments / Reason'}
    ]
);

// ════════════════════════════════════════════════════════════════════
//  VENDORS
// ════════════════════════════════════════════════════════════════════

annotate service.Vendors with @(
    UI.LineItem: [
        { $Type: 'UI.DataField', Value: name,            Label: 'Vendor Name' },
        { $Type: 'UI.DataField', Value: email,           Label: 'Email'       },
        { $Type: 'UI.DataField', Value: phone,           Label: 'Phone'       },
        { $Type: 'UI.DataField', Value: country,         Label: 'Country'     },
        { $Type: 'UI.DataField', Value: currency,        Label: 'Currency'    },
        { $Type: 'UI.DataField', Value: taxID,           Label: 'Tax ID'      },
        { $Type: 'UI.DataField', Value: status,          Label: 'Status'      },
        { $Type: 'UI.DataField', Value: assignedManager, Label: 'Manager'     }
    ],
    UI.SelectionFields: [ status, country, currency ],
    UI.HeaderInfo: {
        TypeName      : 'Vendor',
        TypeNamePlural: 'Vendors',
        Title      : { $Type: 'UI.DataField', Value: name    },
        Description: { $Type: 'UI.DataField', Value: country }
    },
    UI.Facets: [
        {   $Type : 'UI.ReferenceFacet',
            Label : 'Vendor Details',
            Target: '@UI.FieldGroup#VendorDetails' }
    ],
    UI.FieldGroup#VendorDetails: {
        Data: [
            { $Type: 'UI.DataField', Value: name,            Label: 'Name'             },
            { $Type: 'UI.DataField', Value: email,           Label: 'Email'            },
            { $Type: 'UI.DataField', Value: phone,           Label: 'Phone'            },
            { $Type: 'UI.DataField', Value: address,         Label: 'Address'          },
            { $Type: 'UI.DataField', Value: city,            Label: 'City'             },
            { $Type: 'UI.DataField', Value: country,         Label: 'Country'          },
            { $Type: 'UI.DataField', Value: currency,        Label: 'Currency'         },
            { $Type: 'UI.DataField', Value: taxID,           Label: 'Tax ID'           },
            { $Type: 'UI.DataField', Value: externalSystemID,Label: 'S/4HANA Supplier' },
            { $Type: 'UI.DataField', Value: status,          Label: 'Status'           },
            { $Type: 'UI.DataField', Value: assignedManager, Label: 'Assigned Manager' }
        ]
    }
);

// ════════════════════════════════════════════════════════════════════
//  VALUE HELPS
// ════════════════════════════════════════════════════════════════════

// Vendor dropdown on Invoice create/edit
annotate service.Invoices with {
    vendor @(
        Common.Label              : 'Vendor',
        Common.Text               : vendor.name,
        Common.TextArrangement    : #TextOnly,
        Common.ValueList: {
            CollectionPath: 'Vendors',
            Parameters: [
                { $Type: 'Common.ValueListParameterOut',
                  LocalDataProperty: vendor_ID,
                  ValueListProperty: 'ID' },
                { $Type: 'Common.ValueListParameterDisplayOnly',
                  ValueListProperty: 'name' },
                { $Type: 'Common.ValueListParameterDisplayOnly',
                  ValueListProperty: 'country' },
                { $Type: 'Common.ValueListParameterDisplayOnly',
                  ValueListProperty: 'currency' },
                { $Type: 'Common.ValueListParameterDisplayOnly',
                  ValueListProperty: 'status' }
            ]
        }
    );
    currency @(
        Common.Label: 'Currency',
        Common.ValueList: {
            CollectionPath: 'Invoices',
            Parameters: [
                { $Type: 'Common.ValueListParameterOut',
                  LocalDataProperty: currency,
                  ValueListProperty: 'currency' }
            ]
        }
    );
}

// ════════════════════════════════════════════════════════════════════
//  FIELD-LEVEL: MANDATORY + READ-ONLY HINTS
// ════════════════════════════════════════════════════════════════════

annotate service.Invoices with {
    invoiceNumber @(
        Common.FieldControl: #Mandatory,
        Common.Label: 'Invoice Number'
    );
    invoiceDate @(
        Common.FieldControl: #Mandatory,
        Common.Label: 'Invoice Date'
    );
    dueDate @(
        Common.FieldControl: #Mandatory,
        Common.Label: 'Due Date'
    );
    amount @(
        Common.FieldControl: #Mandatory,
        Common.Label: 'Amount',
        Measures.ISOCurrency: currency
    );
    status @(
        Common.Label: 'Status',
        Common.FieldControl: #ReadOnly
    );
    createdBy  @Common.FieldControl: #ReadOnly;
    createdAt  @Common.FieldControl: #ReadOnly;
    submittedBy @Common.FieldControl: #ReadOnly;
    submittedAt @Common.FieldControl: #ReadOnly;
    approvedBy  @Common.FieldControl: #ReadOnly;
    approvedAt  @Common.FieldControl: #ReadOnly;
    rejectedBy  @Common.FieldControl: #ReadOnly;
    rejectedAt  @Common.FieldControl: #ReadOnly;
}

annotate service.InvoiceItems with {
    lineNumber  @Common.FieldControl: #ReadOnly;
    totalAmount @Common.FieldControl: #ReadOnly;
    description @Common.FieldControl: #Mandatory;
    quantity    @Common.FieldControl: #Mandatory;
    unitPrice   @Common.FieldControl: #Mandatory;
}
