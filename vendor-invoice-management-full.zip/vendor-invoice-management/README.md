# Vendor Invoice Management System
**SAP BTP CAMPM Capstone — Enterprise Vendor Invoice Management**

## Project Stack
- **SAP CAP** (Node.js) — service layer & data model
- **HANA Cloud** — production database
- **SQLite** — local development database
- **Fiori Elements** — UI (Day 43)
- **XSUAA** — authentication (Day 44)
- **SAP Build Work Zone** — launchpad (Day 44)

---

## Day 42 — DB Layer Setup

### Prerequisites
```bash
node -v          # >= 18
npm -v           # >= 9
cds --version    # @sap/cds-dk >= 8
```

### 1. Install dependencies
```bash
npm install
```

### 2. Import S/4HANA Business Partner EDMX
Place your downloaded `API_BUSINESS_PARTNER.edmx` in `srv/external/`, then:
```bash
cds import srv/external/API_BUSINESS_PARTNER.edmx --as csn
```

### 3. Compile schema (verify no errors)
```bash
cds compile db/schema.cds
```

### 4. Run locally (auto-loads CSV seed data)
```bash
cds watch
```
Then open **http://localhost:4004**

### 5. Verify entities
| Entity          | Expected rows |
|-----------------|---------------|
| Vendors         | 10            |
| Invoices        | 20 (5D/5S/6A/4R) |
| InvoiceItems    | 45            |
| Attachments     | 10            |
| ApprovalHistory | 25            |

---

## Mocked Users (local dev)
| Username  | Password    | Role           |
|-----------|-------------|----------------|
| admin     | admin123    | Admin          |
| manager1  | manager123  | VendorManager  |
| manager2  | manager123  | VendorManager  |
| approver  | approver123 | Approver       |
| viewer    | viewer123   | Viewer         |

---

## Project Structure
```
vendor-invoice-management/
├── db/
│   ├── schema.cds              ← All 5 entities + enums
│   └── data/                   ← CSV seed data (auto-loaded by cds watch)
│       ├── my.vendor.invoice-Vendors.csv
│       ├── my.vendor.invoice-Invoices.csv
│       ├── my.vendor.invoice-InvoiceItems.csv
│       ├── my.vendor.invoice-Attachments.csv
│       └── my.vendor.invoice-ApprovalHistory.csv
├── srv/                        ← (Day 43) Service definitions + handlers
│   └── external/               ← Place API_BUSINESS_PARTNER.edmx here
├── app/                        ← (Day 43) Fiori Elements UI
├── xs-security.json            ← (Day 44) XSUAA role model
├── mta.yaml                    ← (Day 44) MTA deployment descriptor
└── package.json
```

---

## Day-by-Day Checklist

### Day 42 ✅
- [x] CDS schema with 5 entities
- [x] Enumerations for VendorStatus / InvoiceStatus / ApprovalAction
- [x] `cuid` + `managed` aspects on all relevant entities
- [x] Compositions (Invoices → Items, Attachments, ApprovalHistory)
- [x] Sample data: 10 vendors, 20 invoices, 45 line items, 10 attachments, 25 history rows
- [x] All line-item sums verified against invoice header amounts

### Day 43 (Next)
- [ ] AdminService, VendorManagerService, ApproverService, ViewerService
- [ ] Business logic handlers (submit, approve, reject, sync)
- [ ] S/4HANA integration service
- [ ] Fiori Elements UI with annotations

### Day 44
- [ ] xs-security.json (XSUAA scopes + role templates)
- [ ] mta.yaml (CF deployment descriptor)
- [ ] Cloud Foundry deployment
- [ ] SAP Build Work Zone launchpad configuration
