namespace my.vendor.invoice;

using { cuid, managed } from '@sap/cds/common';

// ============================================================
//  TYPE DEFINITIONS
// ============================================================

type VendorStatus : String(20) enum {
    PENDING   = 'PENDING';
    APPROVED  = 'APPROVED';
    SUSPENDED = 'SUSPENDED';
    DELETED   = 'DELETED';
}

type InvoiceStatus : String(20) enum {
    DRAFT     = 'DRAFT';
    SUBMITTED = 'SUBMITTED';
    APPROVED  = 'APPROVED';
    REJECTED  = 'REJECTED';
    PAID      = 'PAID';
}

type ApprovalAction : String(20) enum {
    SUBMITTED = 'SUBMITTED';
    APPROVED  = 'APPROVED';
    REJECTED  = 'REJECTED';
    PAID      = 'PAID';
}

// ============================================================
//  VENDORS
// ============================================================

/**
 * Vendor master records.
 * Only vendors with status = APPROVED may have invoices raised against them.
 * Vendor Managers are linked via assignedManager (stores the user ID).
 */
@title : 'Vendor'
entity Vendors : cuid, managed {
    @title : 'Vendor Name'
    name             : String(200)  not null;

    @title : 'Email'
    email            : String(200);

    @title : 'Phone'
    phone            : String(50);

    @title : 'Address'
    address          : String(500);

    @title : 'City'
    city             : String(100);

    @title : 'Country'
    country          : String(100)  not null;

    /**
     * ISO 4217 3-letter currency code (e.g. USD, EUR, INR).
     * Defaults to the vendor currency when creating an invoice.
     */
    @title : 'Currency'
    currency         : String(3)    not null;

    @title : 'Tax ID'
    taxID            : String(100);

    /** S/4HANA Business Partner / Supplier number */
    @title : 'External System ID'
    externalSystemID : String(100);

    @title : 'Status'
    status           : VendorStatus default 'PENDING';

    /**
     * User ID of the VendorManager assigned to this vendor.
     * Used for row-level security in the VendorManager service.
     */
    @title : 'Assigned Manager'
    assignedManager  : String(200);

    /** Soft-delete flag — true means the vendor is logically deleted */
    @title : 'Deleted'
    isDeleted        : Boolean      default false;

    /** Back-navigation to all invoices for this vendor */
    invoices         : Association to many Invoices on invoices.vendor = $self;
}

// ============================================================
//  INVOICES
// ============================================================

/**
 * Invoice header.
 * State machine: DRAFT → SUBMITTED → APPROVED → PAID
 *                                  ↓
 *                               REJECTED
 */
@title : 'Invoice'
entity Invoices : cuid, managed {
    @title : 'Invoice Number'
    invoiceNumber    : String(100)   not null;

    @title : 'Vendor'
    vendor           : Association to Vendors not null;

    @title : 'Invoice Date'
    invoiceDate      : Date          not null;

    @title : 'Due Date'
    dueDate          : Date          not null;

    @title : 'Amount'
    amount           : Decimal(15,2) not null;

    @title : 'Currency'
    currency         : String(3)     not null;

    @title : 'Status'
    status           : InvoiceStatus default 'DRAFT';

    @title : 'Notes'
    notes            : String(1000);

    // ── Submission tracking ──────────────────────────────────
    @title : 'Submitted By'
    submittedBy      : String(200);

    @title : 'Submitted At'
    submittedAt      : DateTime;

    // ── Approval tracking ────────────────────────────────────
    @title : 'Approved By'
    approvedBy       : String(200);

    @title : 'Approved At'
    approvedAt       : DateTime;

    @title : 'Approval Comments'
    approvalComments : String(500);

    // ── Rejection tracking ───────────────────────────────────
    @title : 'Rejected By'
    rejectedBy       : String(200);

    @title : 'Rejected At'
    rejectedAt       : DateTime;

    @title : 'Rejection Reason'
    rejectionReason  : String(500);

    // ── Compositions ─────────────────────────────────────────
    items           : Composition of many InvoiceItems   on items.invoice           = $self;
    attachments     : Composition of many Attachments    on attachments.invoice     = $self;
    approvalHistory : Composition of many ApprovalHistory on approvalHistory.invoice = $self;
}

// ============================================================
//  INVOICE LINE ITEMS
// ============================================================

/**
 * Line-item detail for an invoice.
 * totalAmount = quantity × unitPrice (calculated in service handler).
 * At least one line item must exist before an invoice can be submitted.
 * The sum of all line items must equal the invoice header amount.
 */
@title : 'Invoice Line Item'
entity InvoiceItems : cuid {
    @title : 'Invoice'
    invoice     : Association to Invoices not null;

    @title : 'Line No.'
    lineNumber  : Integer        not null;

    @title : 'Description'
    description : String(255)   not null;

    @title : 'Quantity'
    quantity    : Decimal(10,2) not null;

    @title : 'Unit Price'
    unitPrice   : Decimal(15,2) not null;

    /** Stored computed value: quantity × unitPrice */
    @title : 'Total Amount'
    totalAmount : Decimal(15,2);
}

// ============================================================
//  ATTACHMENTS
// ============================================================

/**
 * Supporting documents attached to an invoice.
 * Accepted types: PDF, DOCX, XLSX, PNG, JPG (enforced in service layer).
 * Max file size: 5 MB (enforced in service layer).
 */
@title : 'Attachment'
entity Attachments : cuid, managed {
    @title : 'Invoice'
    invoice    : Association to Invoices not null;

    @title : 'File Name'
    fileName   : String(255) not null;

    /** File size in bytes */
    @title : 'File Size'
    fileSize   : Integer;

    @title : 'MIME Type'
    mimeType   : String(100);

    @title : 'Uploaded By'
    uploadedBy : String(200);

    @title : 'Uploaded At'
    uploadedAt : DateTime;

    @title : 'URL / Path'
    url        : String(500);
}

// ============================================================
//  APPROVAL HISTORY
// ============================================================

/**
 * Immutable audit trail of every workflow action on an invoice.
 * A new record is appended for every SUBMIT / APPROVE / REJECT / PAID event.
 */
@title : 'Approval History'
entity ApprovalHistory : cuid {
    @title : 'Invoice'
    invoice   : Association to Invoices not null;

    @title : 'Action'
    action    : ApprovalAction not null;

    @title : 'Actor Name'
    actor     : String(200)   not null;

    @title : 'Actor ID'
    actorID   : String(200);

    @title : 'Timestamp'
    timestamp : DateTime      not null;

    @title : 'Comments / Reason'
    comments  : String(500);
}
