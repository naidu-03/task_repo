using { my.vendor.invoice as db } from '../db/schema';

/**
 * ViewerService
 * ─────────────────────────────────────────────────────────────────────────────
 * Pure read-only service.  Viewers see only APPROVED and PAID invoices
 * (i.e. fully processed, safe to share).  Analytics shows totals across
 * all statuses so the dashboard is meaningful.
 *
 * Requires the 'Viewer' role.
 */
@path: 'viewer'
service ViewerService @(requires: 'Viewer') {

    @readonly
    entity Invoices as select from db.Invoices
        where status = 'APPROVED'
           or status = 'PAID';

    @readonly
    entity Vendors as projection on db.Vendors
        excluding { invoices };

    @readonly
    entity InvoiceItems    as projection on db.InvoiceItems;

    @readonly
    entity Attachments     as projection on db.Attachments;

    @readonly
    entity ApprovalHistory as projection on db.ApprovalHistory;

    // Analytics — all statuses visible in the reports dashboard
    @readonly
    entity InvoiceStatusSummary as select from db.Invoices {
        status,
        count(ID)   as count       : Integer,
        sum(amount) as totalAmount : Decimal(15,2)
    } group by status;

    @readonly
    entity VendorInvoiceSummary as select from db.Invoices {
        key vendor.ID as vendorID      : UUID,
        vendor.name   as vendorName    : String,
        currency,
        count(ID)     as totalInvoices : Integer,
        sum(amount)   as totalAmount   : Decimal(15,2)
    } group by vendor.ID, vendor.name, currency;
}
