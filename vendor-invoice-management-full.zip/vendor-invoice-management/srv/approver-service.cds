using { my.vendor.invoice as db } from '../db/schema';

/**
 * ApproverService
 * ─────────────────────────────────────────────────────────────────────────────
 * Approvers can read all invoices (so they have full context).
 * approve / reject actions are restricted to SUBMITTED invoices in the handler.
 *
 * The "Approve Invoices" Work Zone tile links to this service with a
 * pre-applied filter ?$filter=status eq 'SUBMITTED'.
 *
 * Requires the 'Approver' role.
 */
@path: 'approver'
service ApproverService @(requires: ['Approver', 'Admin']) {

    // Read-only access to ALL invoices (status filtering done at UI/tile level)
    @readonly
    entity Invoices as projection on db.Invoices
    actions {
        /** Transition SUBMITTED → APPROVED.  Approver ≠ submitter enforced in handler. */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status', '_it/approvedBy', '_it/approvedAt', '_it/approvalComments'
        ] })
        action approveInvoice(comments : String(500)) returns Invoices;

        /** Transition SUBMITTED → REJECTED.  Reason is mandatory. */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status', '_it/rejectedBy', '_it/rejectedAt', '_it/rejectionReason'
        ] })
        action rejectInvoice(reason : String(500))   returns Invoices;
    };

    @readonly
    entity Vendors as projection on db.Vendors
        excluding { invoices };

    @readonly
    entity InvoiceItems    as projection on db.InvoiceItems;

    @readonly
    entity Attachments     as projection on db.Attachments;

    @readonly
    entity ApprovalHistory as projection on db.ApprovalHistory;

    // Analytics — full picture (all statuses) for the reports dashboard
    @readonly
    entity InvoiceStatusSummary as select from db.Invoices {
        status,
        count(ID)   as count       : Integer,
        sum(amount) as totalAmount : Decimal(15,2)
    } group by status;

    @readonly
    entity VendorInvoiceSummary as select from db.Invoices {
        key vendor.ID as vendorID      : UUID,
        vendor.name   as vendorName    : String,
        currency,
        count(ID)     as totalInvoices : Integer,
        sum(amount)   as totalAmount   : Decimal(15,2)
    } group by vendor.ID, vendor.name, currency;
}
