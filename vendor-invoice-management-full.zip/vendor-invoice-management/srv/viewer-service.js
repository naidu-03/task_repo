'use strict';
const cds = require('@sap/cds');

/**
 * ViewerService handler — intentionally empty.
 * All access control is declared in viewer-service.cds via:
 *   @(requires: 'Viewer') on the service
 *   @readonly             on every entity
 *   where status = ...    WHERE clause in entity projections
 *
 * CAP's generic handlers cover READ automatically.
 */
module.exports = class ViewerService extends cds.ApplicationService {
    async init() {
        await super.init();
    }
};
