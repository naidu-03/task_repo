'use strict';
const cds = require('@sap/cds');
const utils = require('./lib/invoice-utils');

module.exports = class ApproverService extends cds.ApplicationService {

    async init() {
        const db = await cds.connect.to('db');
        const { Invoices, ApprovalHistory } = cds.entities('my.vendor.invoice');

        // ════════════════════════════════════════════════════════════════
        //  APPROVE ACTION
        // ════════════════════════════════════════════════════════════════

        this.on('approveInvoice', 'Invoices', async (req) => {
            const { ID }      = req.params[0];
            const { comments } = req.data;

            // Delegate to shared utility (handles all validations + history)
            return utils.approveInvoice(ID, comments, req, db, Invoices, ApprovalHistory);
        });

        // ════════════════════════════════════════════════════════════════
        //  REJECT ACTION
        // ════════════════════════════════════════════════════════════════

        this.on('rejectInvoice', 'Invoices', async (req) => {
            const { ID }     = req.params[0];
            const { reason } = req.data;

            // Delegate to shared utility (handles all validations + history)
            return utils.rejectInvoice(ID, reason, req, db, Invoices, ApprovalHistory);
        });

        await super.init();
    }
};
