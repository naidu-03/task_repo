using { my.vendor.invoice as db } from '../db/schema';

/**
 * AdminService
 * ─────────────────────────────────────────────────────────────────────────────
 * Full CRUD access to all entities.
 * Exposes workflow actions, analytics views, and the S/4HANA vendor sync.
 * Restricted to users with the 'Admin' role.
 */
@path: 'admin'
service AdminService @(requires: 'Admin') {

    // ── VENDOR MANAGEMENT ────────────────────────────────────────────────────
    entity Vendors as projection on db.Vendors
        excluding { invoices }
    actions {
        /** Approve a PENDING or SUSPENDED vendor so it can receive invoices. */
        @(Common.SideEffects: { TargetProperties: ['_it/status'] })
        action approveVendor()  returns Vendors;

        /** Suspend an APPROVED vendor (blocks new invoice creation). */
        @(Common.SideEffects: { TargetProperties: ['_it/status'] })
        action suspendVendor()  returns Vendors;
    };

    // ── INVOICE MANAGEMENT ───────────────────────────────────────────────────
    /**
     * Draft-enabled so incomplete invoices survive browser-close.
     * Drafts are auto-discarded after 30 days by the CDS framework.
     */
    @odata.draft.enabled
    entity Invoices as projection on db.Invoices
    actions {
        /** Transition DRAFT → SUBMITTED.  Validates line items and sum. */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status','_it/submittedBy','_it/submittedAt'
        ] })
        action submitForApproval()                       returns Invoices;

        /** Transition SUBMITTED → APPROVED. */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status','_it/approvedBy','_it/approvedAt','_it/approvalComments'
        ] })
        action approveInvoice(comments : String(500))    returns Invoices;

        /** Transition SUBMITTED → REJECTED.  Reason is mandatory. */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status','_it/rejectedBy','_it/rejectedAt','_it/rejectionReason'
        ] })
        action rejectInvoice(reason   : String(500))     returns Invoices;

        /** Bonus: Transition APPROVED → PAID. */
        @(Common.SideEffects: { TargetProperties: ['_it/status'] })
        action markAsPaid()                              returns Invoices;
    };

    entity InvoiceItems    as projection on db.InvoiceItems;
    entity Attachments     as projection on db.Attachments;

    @readonly
    entity ApprovalHistory as projection on db.ApprovalHistory;

    // ── ANALYTICS VIEWS ──────────────────────────────────────────────────────

    /** KPI / pie-chart data: count and total amount by status. */
    @readonly
    entity InvoiceStatusSummary as select from db.Invoices {
        status,
        count(ID)   as count       : Integer,
        sum(amount) as totalAmount : Decimal(15,2)
    } group by status;

    /**
     * Bar-chart / table data: per-vendor totals.
     * Top-5 vendors by invoice amount are rendered in the analytics dashboard.
     */
    @readonly
    entity VendorInvoiceSummary as select from db.Invoices {
        key vendor.ID as vendorID      : UUID,
        vendor.name   as vendorName    : String,
        currency,
        count(ID)     as totalInvoices : Integer,
        sum(amount)   as totalAmount   : Decimal(15,2)
    } group by vendor.ID, vendor.name, currency;

    // ── S/4HANA SYNC ─────────────────────────────────────────────────────────

    type SyncResult {
        totalVendors   : Integer;
        newVendors     : Integer;
        updatedVendors : Integer;
        syncTime       : String;
        message        : String;
    }

    /** Pull suppliers from S/4HANA Business Partner API and upsert locally. */
    action syncVendorsFromS4HANA() returns SyncResult;
}
