'use strict';
const cds = require('@sap/cds');
const utils = require('./lib/invoice-utils');

module.exports = class VendorManagerService extends cds.ApplicationService {

    async init() {
        const db = await cds.connect.to('db');
        const {
            Vendors, Invoices, InvoiceItems, ApprovalHistory
        } = cds.entities('my.vendor.invoice');

        // ── Helper: verify invoice belongs to current manager ──────────────────
        const _ownedInvoice = async (invoiceID, userID) => {
            const inv = await db.run(
                SELECT.one.from(Invoices, ['ID', 'status', 'vendor_ID'])
                    .where({ ID: invoiceID })
            );
            if (!inv) return null;

            const vendor = await db.run(
                SELECT.one.from(Vendors, ['assignedManager'])
                    .where({ ID: inv.vendor_ID })
            );
            if (!vendor || vendor.assignedManager !== userID) return null;
            return inv;
        };

        // ── Helper: verify item belongs to current manager ─────────────────────
        const _ownedItem = async (invoiceID, userID) => {
            const inv = await db.run(
                SELECT.one.from(Invoices, ['ID', 'status', 'vendor_ID'])
                    .where({ ID: invoiceID })
            );
            if (!inv) return null;
            const vendor = await db.run(
                SELECT.one.from(Vendors, ['assignedManager'])
                    .where({ ID: inv.vendor_ID })
            );
            if (!vendor || vendor.assignedManager !== userID) return null;
            return inv;
        };

        // ════════════════════════════════════════════════════════════════
        //  INVOICE WRITE GUARDS
        // ════════════════════════════════════════════════════════════════

        /** Validate new invoice header + ownership */
        this.before('CREATE', 'Invoices', async (req) => {
            const userID = req.user.id;

            // Ensure vendor is assigned to this manager
            if (req.data.vendor_ID) {
                const vendor = await db.run(
                    SELECT.one.from(Vendors, ['assignedManager', 'status', 'isDeleted', 'name'])
                        .where({ ID: req.data.vendor_ID })
                );
                if (!vendor || vendor.assignedManager !== userID)
                    return req.error(403,
                        'You can only create invoices for your assigned vendors');
            }

            await utils.validateInvoiceData(req, db, Vendors, Invoices, true);
        });

        /** Validate on draft Save */
        this.before('SAVE', 'Invoices', async (req) => {
            await utils.validateInvoiceData(req, db, Vendors, Invoices, false);
        });

        /** Guard UPDATE — ownership + DRAFT-only */
        this.before('UPDATE', 'Invoices', async (req) => {
            const { ID } = req.params[0] || {};
            if (!ID) return;

            const inv = await _ownedInvoice(ID, req.user.id);
            if (!inv) return req.error(403,
                'Access denied. You do not have permission to modify this invoice.');
            if (inv.status !== 'DRAFT')
                return req.error(400,
                    `Invoice in ${inv.status} status cannot be edited`);
        });

        /** Guard DELETE — only DRAFT invoices */
        this.before('DELETE', 'Invoices', async (req) => {
            const { ID } = req.params[0] || {};
            if (!ID) return;

            const inv = await _ownedInvoice(ID, req.user.id);
            if (!inv) return req.error(403, 'Access denied');
            if (inv.status !== 'DRAFT')
                return req.error(400, 'Only DRAFT invoices can be deleted');
        });

        // ── LINE ITEMS ────────────────────────────────────────────────

        /** Auto-calculate totalAmount */
        this.before(['CREATE', 'UPDATE'], 'InvoiceItems', (req) => {
            utils.calcLineItemTotal(req);
        });

        /** Ownership + DRAFT guard on line items */
        this.before(['CREATE', 'UPDATE', 'DELETE'], 'InvoiceItems', async (req) => {
            const data = req.data || {};
            const invoiceID = data.invoice_ID ||
                (req.params[0] && req.params[0].invoice_ID);
            if (!invoiceID) return;

            const inv = await _ownedItem(invoiceID, req.user.id);
            if (!inv) return req.error(403,
                'Access denied. You cannot modify line items for this invoice.');
            if (inv.status !== 'DRAFT')
                return req.error(400,
                    'Line items can only be modified on DRAFT invoices');
        });

        // ════════════════════════════════════════════════════════════════
        //  WORKFLOW ACTIONS
        // ════════════════════════════════════════════════════════════════

        this.on('submitForApproval', 'Invoices', async (req) => {
            const { ID } = req.params[0];
            // Extra ownership check before submitting
            const inv = await _ownedInvoice(ID, req.user.id);
            if (!inv) return req.error(403,
                'You do not have permission to submit this invoice');

            return utils.submitInvoice(ID, req, db, Invoices, InvoiceItems, ApprovalHistory);
        });

        await super.init();
    }
};
