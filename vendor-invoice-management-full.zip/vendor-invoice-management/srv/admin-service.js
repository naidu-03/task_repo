'use strict';
const cds = require('@sap/cds');
const utils = require('./lib/invoice-utils');

module.exports = class AdminService extends cds.ApplicationService {

    async init() {
        const db = await cds.connect.to('db');
        // Use raw DB entities to bypass service-level restrictions in handlers
        const {
            Vendors, Invoices, InvoiceItems, Attachments, ApprovalHistory
        } = cds.entities('my.vendor.invoice');

        // ════════════════════════════════════════════════════════════════
        //  VENDOR HANDLERS
        // ════════════════════════════════════════════════════════════════

        /** Basic field validation on create/update */
        this.before(['CREATE', 'UPDATE'], 'Vendors', (req) => {
            const v = req.data;
            if (req.event === 'CREATE') {
                if (!v.name)     return req.error(400, 'Vendor name is required');
                if (!v.country)  return req.error(400, 'Country is required');
                if (!v.currency) return req.error(400, 'Currency is required');
            }
        });

        /** PATCH status → APPROVED */
        this.on('approveVendor', 'Vendors', async (req) => {
            const { ID } = req.params[0];
            const vendor = await db.run(SELECT.one.from(Vendors).where({ ID }));
            if (!vendor) return req.error(404, 'Vendor not found');
            if (vendor.status === 'DELETED')
                return req.error(400, 'Deleted vendors cannot be approved');

            await db.run(UPDATE(Vendors).set({ status: 'APPROVED' }).where({ ID }));
            return db.run(SELECT.one.from(Vendors).where({ ID }));
        });

        /** PATCH status → SUSPENDED */
        this.on('suspendVendor', 'Vendors', async (req) => {
            const { ID } = req.params[0];
            const vendor = await db.run(SELECT.one.from(Vendors).where({ ID }));
            if (!vendor) return req.error(404, 'Vendor not found');
            if (vendor.status === 'DELETED')
                return req.error(400, 'Deleted vendors cannot be suspended');

            await db.run(UPDATE(Vendors).set({ status: 'SUSPENDED' }).where({ ID }));
            return db.run(SELECT.one.from(Vendors).where({ ID }));
        });

        /** Soft-delete: set isDeleted=true, status=DELETED instead of physical DELETE */
        this.before('DELETE', 'Vendors', async (req) => {
            const { ID } = req.params[0];
            // Check for active (non-rejected, non-draft) invoices
            const activeInv = await db.run(
                SELECT.one.from(Invoices)
                    .where({ vendor_ID: ID })
                    .and(`status IN ('SUBMITTED','APPROVED')`)
            );
            if (activeInv)
                return req.error(409,
                    'Cannot delete vendor with active (SUBMITTED or APPROVED) invoices');

            // Convert DELETE → soft delete
            await db.run(
                UPDATE(Vendors).set({ isDeleted: true, status: 'DELETED' }).where({ ID })
            );
            req.reply(204); // Cancel the actual DELETE
        });

        // ════════════════════════════════════════════════════════════════
        //  INVOICE HANDLERS
        // ════════════════════════════════════════════════════════════════

        /** Validate header fields when creating a new invoice (draft) */
        this.before('CREATE', 'Invoices', async (req) => {
            await utils.validateInvoiceData(req, db, Vendors, Invoices, true);
        });

        /** Validate header fields on draft activation (Save button) */
        this.before('SAVE', 'Invoices', async (req) => {
            await utils.validateInvoiceData(req, db, Vendors, Invoices, false);
        });

        /** Enforce immutability: SUBMITTED/APPROVED/REJECTED invoices are read-only */
        this.before('UPDATE', 'Invoices', async (req) => {
            const { ID } = req.params[0] || {};
            if (!ID) return;
            const inv = await db.run(SELECT.one.from(Invoices, ['status']).where({ ID }));
            if (inv && ['SUBMITTED','APPROVED','REJECTED','PAID'].includes(inv.status))
                return req.error(400,
                    `Invoice in ${inv.status} status cannot be edited`);
        });

        // ── LINE ITEMS ────────────────────────────────────────────────

        /** Auto-calculate totalAmount on every line item write */
        this.before(['CREATE', 'UPDATE'], 'InvoiceItems', (req) => {
            utils.calcLineItemTotal(req);
        });

        /** Prevent adding/editing line items on non-DRAFT invoices */
        this.before(['CREATE', 'UPDATE', 'DELETE'], 'InvoiceItems', async (req) => {
            const item = req.data || {};
            // For CREATE the invoiceID is in data; for DELETE it's in params
            const invoiceID =
                item.invoice_ID ||
                (req.params[0] && req.params[0].invoice_ID);
            if (!invoiceID) return;

            const inv = await db.run(
                SELECT.one.from(Invoices, ['status']).where({ ID: invoiceID })
            );
            if (inv && inv.status !== 'DRAFT')
                return req.error(400,
                    'Line items can only be modified on DRAFT invoices');
        });

        // ── WORKFLOW ACTIONS ──────────────────────────────────────────

        this.on('submitForApproval', 'Invoices', async (req) => {
            const { ID } = req.params[0];
            return utils.submitInvoice(ID, req, db, Invoices, InvoiceItems, ApprovalHistory);
        });

        this.on('approveInvoice', 'Invoices', async (req) => {
            const { ID } = req.params[0];
            const { comments } = req.data;
            return utils.approveInvoice(ID, comments, req, db, Invoices, ApprovalHistory);
        });

        this.on('rejectInvoice', 'Invoices', async (req) => {
            const { ID } = req.params[0];
            const { reason } = req.data;
            return utils.rejectInvoice(ID, reason, req, db, Invoices, ApprovalHistory);
        });

        this.on('markAsPaid', 'Invoices', async (req) => {
            const { ID } = req.params[0];
            return utils.markAsPaid(ID, req, db, Invoices, ApprovalHistory);
        });

        // ════════════════════════════════════════════════════════════════
        //  S/4HANA VENDOR SYNC
        // ════════════════════════════════════════════════════════════════

        this.on('syncVendorsFromS4HANA', async (req) => {
            let s4;
            try {
                s4 = await cds.connect.to('API_BUSINESS_PARTNER');
            } catch {
                // Return mock result when S/4HANA destination is not configured
                return {
                    totalVendors:   0,
                    newVendors:     0,
                    updatedVendors: 0,
                    syncTime:       new Date().toISOString(),
                    message:        'S/4HANA destination not configured — running in mock mode.'
                };
            }

            try {
                const { A_Supplier } = s4.entities;

                // Fetch up to 200 suppliers from S/4HANA
                const suppliers = await s4.run(
                    SELECT.from(A_Supplier)
                        .columns(
                            'Supplier', 'SupplierName', 'Country',
                            'CorrespondenceLanguage', 'CreatedByUser'
                        )
                        .limit(200)
                );

                let newCount     = 0;
                let updatedCount = 0;

                for (const s of suppliers) {
                    const existing = await db.run(
                        SELECT.one.from(Vendors).where({ externalSystemID: s.Supplier })
                    );

                    if (existing) {
                        // UPDATE — keep local status / other fields intact
                        await db.run(
                            UPDATE(Vendors).set({
                                name:    s.SupplierName || existing.name,
                                country: s.Country      || existing.country
                            }).where({ ID: existing.ID })
                        );
                        updatedCount++;
                    } else {
                        // INSERT — new vendors start as PENDING (require approval)
                        await db.run(
                            INSERT.into(Vendors).entries({
                                ID:               cds.utils.uuid(),
                                name:             s.SupplierName || `Supplier ${s.Supplier}`,
                                country:          s.Country      || 'Unknown',
                                currency:         'USD',          // default; admin can update
                                status:           'PENDING',
                                externalSystemID: s.Supplier,
                                isDeleted:        false
                            })
                        );
                        newCount++;
                    }
                }

                return {
                    totalVendors:   suppliers.length,
                    newVendors:     newCount,
                    updatedVendors: updatedCount,
                    syncTime:       new Date().toISOString(),
                    message: `Sync completed. ${newCount} new vendor(s), ${updatedCount} updated.`
                };

            } catch (err) {
                req.error(500, `S/4HANA sync failed: ${err.message}`);
            }
        });

        // Criticality for Fiori Elements status badges
        // 0=Neutral 1=Error(red) 2=Warning(yellow) 3=Success(green) 5=Info(blue)
        const _CRIT = { DRAFT: 0, SUBMITTED: 2, APPROVED: 3, REJECTED: 1, PAID: 5 };
        this.after('READ', 'Invoices', (results) => {
            (Array.isArray(results) ? results : [results]).forEach(inv => {
                if (inv) inv.statusCriticality = _CRIT[inv.status] ?? 0;
            });
        });

                await super.init();
    }
};
