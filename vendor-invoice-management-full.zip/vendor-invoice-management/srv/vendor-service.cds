using { my.vendor.invoice as db } from '../db/schema';

/**
 * VendorManagerService
 * ─────────────────────────────────────────────────────────────────────────────
 * Restricted to invoices and vendors where assignedManager = current user.
 * Row-level security is enforced both by the WHERE clause in projections
 * and by before-handlers that validate every write operation.
 *
 * Requires the 'VendorManager' role.
 */
@path: 'vendor'
service VendorManagerService @(requires: 'VendorManager') {

    // ── VENDORS ───────────────────────────────────────────────────────────────
    /**
     * Read-only list of APPROVED, non-deleted vendors assigned to this manager.
     * Used to populate the vendor dropdown when creating an invoice.
     */
    @readonly
    entity Vendors as select from db.Vendors {
        ID, name, email, phone, address, city,
        country, currency, taxID, status,
        assignedManager, createdAt
    } where assignedManager = $user
        and status          = 'APPROVED'
        and isDeleted       = false;

    // ── INVOICES ──────────────────────────────────────────────────────────────
    /**
     * Invoices that belong to this manager's vendors only.
     * The WHERE clause filters reads; before-handlers protect writes.
     */
    @odata.draft.enabled
    entity Invoices as select from db.Invoices
        where vendor.assignedManager = $user
    actions {
        /** Transition DRAFT → SUBMITTED */
        @(Common.SideEffects: { TargetProperties: [
            '_it/status', '_it/submittedBy', '_it/submittedAt'
        ] })
        action submitForApproval() returns Invoices;
    };

    entity InvoiceItems    as projection on db.InvoiceItems;
    entity Attachments     as projection on db.Attachments;

    @readonly
    entity ApprovalHistory as projection on db.ApprovalHistory;

    // ── ANALYTICS (scoped to this manager's vendors) ──────────────────────────
    @readonly
    entity InvoiceStatusSummary as select from db.Invoices {
        status,
        count(ID)   as count       : Integer,
        sum(amount) as totalAmount : Decimal(15,2)
    } where vendor.assignedManager = $user
      group by status;
}
